/*

eLearnSecurity 2013

*/


#include <iostream>
using namespace std;
      
int main ()
{
    cout << "Hello World!";
    cin.ignore();
    
    return 0;   
    
}
