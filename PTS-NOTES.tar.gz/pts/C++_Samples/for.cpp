/*

eLearnSecurity 2013

*/

#include <iostream> 
using namespace std; 

int main ()
 {

    int a;
    
    for (a = 2; a <= 50; a = a+2){
        
        cout << a << "-";
        
        }
        
    cin.ignore();
	return 0;
 } 
 
 

